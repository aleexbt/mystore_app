import 'package:flutter/material.dart';

Color kPrimaryColor = Color.fromARGB(255, 211, 110, 130);

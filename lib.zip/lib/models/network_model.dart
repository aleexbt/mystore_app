class NetworkHandler {
  int statusCode;
  bool error;
  dynamic response;

  NetworkHandler({this.statusCode, this.error, this.response});
}
